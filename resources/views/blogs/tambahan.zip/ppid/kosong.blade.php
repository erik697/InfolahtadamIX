@extends('blogs.template.ppidT')
@section('title', 'Infolahtadam IX')
@section('content')
<div class="min-h-full pt-32">
    <div class="mx-4 lg:mx-32">

{{-- <div class=" bg-green-800 text-white my-4">
            <div class="px-4 py-2 text-center uppercase">
                
            </div>
        </div> --}}
      {{-- tentang start --}}
        <div class="my-24 lg:mx-32 lg:my-32">

        </div>
    </div>
      {{-- tentang end --}}


    </div>
</div>
